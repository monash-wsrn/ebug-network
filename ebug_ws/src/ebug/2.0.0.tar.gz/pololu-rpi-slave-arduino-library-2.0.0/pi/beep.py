# Copyright Pololu Corporation.  For more information, see https://www.pololu.com/
from a_star import AStar

a_star = AStar()

a_star.play_notes("o4l16ceg>c8")
